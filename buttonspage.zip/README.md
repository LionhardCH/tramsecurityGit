# 	Tram Security

- NodeJs App
- simulates data stream from resources.
- The live data stream visualized in a map (Google Maps)

